import {DynamoDB, DynamoDBClient, ListTablesCommand} from "@aws-sdk/client-dynamodb";

import { marshall, unmarshall } from '@aws-sdk/util-dynamodb';

export async function handler(params) {

    const client = new DynamoDBClient( params );

    try {
        const results = await client.send(new ListTablesCommand({}));

        return results?.TableNames;

    } catch (error) {
        console.error('error: ' + error.name);
        return 'error: ' + error.name;

    }

}
